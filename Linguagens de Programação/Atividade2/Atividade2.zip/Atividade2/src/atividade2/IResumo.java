// Rodrigo Franciozi 14.04014-0
//Igor Amaral 15.00588-7

package atividade2;

public interface IResumo {
    
    public abstract String retornarResumo();
    
}
